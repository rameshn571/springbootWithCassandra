package com.sample.demo.service;

import java.util.List;

import com.sample.demo.beans.Tickets;

public interface TicketsService {

	List<Tickets> getAllBookingTickets();

}
