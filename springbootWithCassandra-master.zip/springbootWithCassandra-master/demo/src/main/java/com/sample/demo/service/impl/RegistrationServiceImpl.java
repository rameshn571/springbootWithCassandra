package com.sample.demo.service.impl;

import java.util.List;

import com.sample.demo.beans.Registration;
import com.sample.demo.service.RegistrationService;

public class RegistrationServiceImpl implements RegistrationService {

	@Override
	public List<Registration> getAllRegistrations() {
		return null;
	}

}
