package com.sample.demo.service;

import java.util.List;

import com.sample.demo.beans.Person;

public interface PersonService {
	
	List<Person> listAll();

}
