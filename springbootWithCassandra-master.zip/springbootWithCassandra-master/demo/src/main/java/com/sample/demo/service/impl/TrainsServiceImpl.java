package com.sample.demo.service.impl;

import java.util.List;

import com.sample.demo.beans.Trains;
import com.sample.demo.service.TrainsService;

public class TrainsServiceImpl implements TrainsService {

	@Override
	public List<Trains> getAllTrains() {
		return null;
	}

}
