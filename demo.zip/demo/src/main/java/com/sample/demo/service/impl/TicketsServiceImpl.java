package com.sample.demo.service.impl;

import java.util.List;

import com.sample.demo.beans.Tickets;
import com.sample.demo.service.TicketsService;

public class TicketsServiceImpl implements TicketsService {

	@Override
	public List<Tickets> getAllBookingTickets() {
		return null;
	}

}
