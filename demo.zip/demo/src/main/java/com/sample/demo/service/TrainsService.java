package com.sample.demo.service;

import java.util.List;

import com.sample.demo.beans.Trains;

public interface TrainsService {
	
	List<Trains> getAllTrains();


}
