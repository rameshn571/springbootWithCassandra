package com.sample.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sample.demo.beans.Registration;
import com.sample.demo.repository.RegistrationRepository;
import com.sample.demo.service.RegistrationService;

@Service
public class RegistrationServiceImpl implements RegistrationService {
	
	@Autowired
	private RegistrationRepository registrationRepository;

	@Override
	public List<Registration> findAll() {
		return registrationRepository.findAll();
	}

	@Override
	public Registration create(Registration registration) {
		return registrationRepository.save(registration);
	}

}
